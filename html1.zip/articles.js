// Shared Insights article content. Keyed by slug; consumed by Article.dc.html.
export const ARTICLES = {
  'credibility-not-noise': {
    cat: 'THOUGHT LEADERSHIP', read: '8 MIN READ', date: 'JUN 2026', author: 'STRATEM',
    title: 'Why professional-services firms win on credibility, not noise',
    dek: 'In a market where every firm claims expertise, earned authority is the only defensible advantage. Here is how to build it deliberately.',
    body: [
      { kind: 'p', text: 'Walk into any professional-services market and you will hear the same words: trusted, expert, partner-led, results-driven. When everyone says the same thing, the words stop working. The firms that win attention are not the ones that shout loudest. They are the ones a client, a journalist or an investor already believes before the meeting starts.' },
      { kind: 'p', text: 'That belief is credibility, and unlike advertising it cannot be bought in a single campaign. It is accumulated, through consistent visibility in the right places, said by the right people, over time. This is the work growth PR is built to do.' },
      { kind: 'h', text: 'Noise is easy. Authority is earned.' },
      { kind: 'p', text: 'A press release blasted to a thousand contacts is noise. A single, well-placed comment from your managing partner in a title your clients actually read is authority. The difference is not volume, it is relevance and trust, and the second is worth far more than the first.' },
      { kind: 'list', text: 'Three things credibility needs that noise never delivers:', items: [
        'A point of view that is genuinely yours, not a rewording of the category.',
        'Repetition in the specific outlets your buyers and referrers pay attention to.',
        'A named human voice, because people trust people, not logos.'] },
      { kind: 'h', text: 'Building it deliberately' },
      { kind: 'p', text: 'Start with the question your best clients are actually asking, then make your firm the clearest answer to it. Give your senior people a small number of sharp opinions and put them, consistently, where they will be seen. Track whether the right people are noticing, not how many pieces of coverage you counted.' },
      { kind: 'quote', text: 'The goal is not to be everywhere. It is to be unmistakable to the few hundred people who decide whether your firm grows.' },
      { kind: 'p', text: 'Do that for a year and something changes: the inbound conversations start warmer, the pitches get shorter, and the price conversation gets easier. That is what credibility buys, and it is why it beats noise every time.' },
    ],
  },
  'what-journalists-want': {
    cat: 'MEDIA RELATIONS', read: '5 MIN READ', date: 'JUN 2026', author: 'STRATEM',
    title: 'What journalists actually want from expert sources',
    dek: 'Most pitches fail for the same few reasons. Understand what a journalist is really looking for and you become the source they call first.',
    body: [
      { kind: 'p', text: 'Journalists are not gatekeepers to be outsmarted. They are busy people with deadlines who need one thing from an expert source: to make their story better, faster. Firms that internalise this stop pitching and start helping, and their coverage improves overnight.' },
      { kind: 'h', text: 'What earns the call-back' },
      { kind: 'list', text: '', items: [
        'A genuine, quotable opinion, not a neutral summary of both sides.',
        'Speed, because a comment an hour late is a comment that never runs.',
        'Relevance to what they are writing this week, not what you want to sell.',
        'Availability of a real, named, senior person who can speak with authority.'] },
      { kind: 'h', text: 'What gets you deleted' },
      { kind: 'p', text: 'Jargon, embargoed fluff, a refusal to say anything interesting, and follow-up chasing. If your comment could have come from any firm in your sector, it will be used by none.' },
      { kind: 'quote', text: 'The most valuable thing you can give a journalist is a strong, clear view they can quote and stand behind.' },
      { kind: 'p', text: 'Become reliably useful and something compounds: you move from cold pitches to the contacts list, and the next story comes to you.' },
    ],
  },
  'deal-first-24-hours': {
    cat: 'M&A', read: '6 MIN READ', date: 'MAY 2026', author: 'STRATEM',
    title: 'Communicating a deal: the first 24 hours that set the tone',
    dek: 'The narrative of a transaction is set in its opening day. Get the first 24 hours right and you spend the rest of the process defending a strong position, not repairing a weak one.',
    body: [
      { kind: 'p', text: 'By the time a deal is announced, the outcome of its communications has largely been decided. The winners are the teams that treated the announcement as the midpoint of a plan, not the start of one. The first day sets the frame every subsequent story is written inside.' },
      { kind: 'h', text: 'Before the announcement' },
      { kind: 'list', text: '', items: [
        'Agree the single sentence that explains why the deal makes sense.',
        'Map every audience, employees, clients, regulators, press, and sequence who hears what, when.',
        'Prepare for the three hardest questions, because they will be asked first.'] },
      { kind: 'h', text: 'In the first 24 hours' },
      { kind: 'p', text: 'Move quickly and speak with one voice. Silence is a vacuum that others fill on your behalf, usually unhelpfully. Brief your own people before they read it in the news, and give trusted journalists the context they need to get the story right the first time.' },
      { kind: 'quote', text: 'Control the frame early and the rest of the process is defending a strong position, not repairing a weak one.' },
      { kind: 'p', text: 'Deals are stressful and fast-moving. A calm, prepared communications plan is what keeps a rational story on track when the pressure is highest.' },
    ],
  },
  'messaging-test': {
    cat: 'POSITIONING', read: '4 MIN READ', date: 'MAY 2026', author: 'STRATEM',
    title: 'The messaging test every leadership team should run',
    dek: 'If your leaders describe the firm differently, so will the market. A simple exercise reveals whether your positioning is actually shared.',
    body: [
      { kind: 'p', text: 'Here is a quick, uncomfortable exercise. Ask each member of your leadership team, separately, to write down in one sentence what your firm does and why it is different. Then compare the answers. If they diverge, and they usually do, you have found the reason your marketing feels scattered and your pitches feel generic.' },
      { kind: 'h', text: 'Why it matters' },
      { kind: 'p', text: 'Every partner is a channel. If they each describe the firm differently, the market receives noise, not a position. Consistency is not about scripting people, it is about giving them a shared, sharp answer they genuinely believe and can say in their own words.' },
      { kind: 'list', text: 'A strong positioning statement is:', items: [
        'Specific enough that a competitor could not truthfully claim it.',
        'Short enough to survive being repeated by a busy person.',
        'True enough that your own people nod when they hear it.'] },
      { kind: 'quote', text: 'You do not have a positioning problem until your own leaders answer the question differently. Then you have nothing else.' },
      { kind: 'p', text: 'Run the test once a year. Alignment drifts, and catching it early is far cheaper than rebuilding a brand that quietly lost its point.' },
    ],
  },
  'executive-linkedin': {
    cat: 'DIGITAL', read: '7 MIN READ', date: 'APR 2026', author: 'STRATEM',
    title: 'Executive LinkedIn that builds authority, not vanity',
    dek: 'Most executive LinkedIn is a waste of a leader\u2019s time. Done well, it is one of the highest-return channels a professional-services firm has.',
    body: [
      { kind: 'p', text: 'LinkedIn rewards consistency and punishes vanity. A leader posting milestone announcements and reshared company news builds nothing. A leader sharing a genuine, specific view on their field, regularly, builds a reputation that opens doors long before any sales conversation.' },
      { kind: 'h', text: 'What actually works' },
      { kind: 'list', text: '', items: [
        'A narrow set of themes the leader is genuinely known for.',
        'Opinions and observations, not links and logos.',
        'A real voice, ghost-supported but never ghost-written into blandness.',
        'A steady rhythm, because authority is built by showing up, not going viral.'] },
      { kind: 'h', text: 'The compounding effect' },
      { kind: 'p', text: 'The first month feels like shouting into a void. By month six, prospects mention your posts in meetings, journalists cite your view, and recruits arrive already convinced. The return is not in any single post, it is in the position you accumulate.' },
      { kind: 'quote', text: 'Nobody hires a firm because its CEO posted a conference photo. They hire because they have quietly decided that CEO knows what they are talking about.' },
      { kind: 'p', text: 'Treat it as a discipline, protect a small slot of the leader\u2019s time, and it becomes one of the cheapest sources of qualified attention a firm has.' },
    ],
  },
  'crisis-preparation': {
    cat: 'CRISIS', read: '6 MIN READ', date: 'APR 2026', author: 'STRATEM',
    title: 'Preparing for the incident you hope never happens',
    dek: 'Reputations are rarely lost in the crisis itself. They are lost in the hours of hesitation before anyone knows what to do. Preparation removes the hesitation.',
    body: [
      { kind: 'p', text: 'Every firm believes it will handle a crisis well until it is inside one. In the moment, information is incomplete, everyone has an opinion, and the clock is merciless. The firms that come through with reputation intact are almost always the ones that did the boring work in advance.' },
      { kind: 'h', text: 'What preparation looks like' },
      { kind: 'list', text: '', items: [
        'A named crisis team with clear roles and the authority to act.',
        'Pre-agreed principles for what you will and will not say.',
        'Holding statements drafted for the scenarios most likely to hit you.',
        'One rehearsed simulation, because plans on paper fail under real pressure.'] },
      { kind: 'quote', text: 'You cannot script a crisis. But you can decide, calmly and in advance, how you will behave when one arrives.' },
      { kind: 'h', text: 'The first hour' },
      { kind: 'p', text: 'Acknowledge quickly, tell the truth, and show you are acting. Audiences forgive problems far more readily than they forgive evasion. Speed and honesty in the first hour buy you the room to manage everything that follows.' },
      { kind: 'p', text: 'The best crisis is the one nobody outside the room ever hears about. Preparation is what makes that outcome possible.' },
    ],
  },
  'growth-story-risk': {
    cat: 'FINANCIAL COMMS', read: '5 MIN READ', date: 'MAR 2026', author: 'STRATEM',
    title: 'Telling a growth story to an audience that prices risk',
    dek: 'Investors and analysts do not buy optimism. They buy a credible path with the risks named. The firms that raise well are the ones that understand the difference.',
    body: [
      { kind: 'p', text: 'A growth story told to customers can be pure ambition. The same story told to investors has to survive a very different reader, one whose job is to find the flaw before they commit capital. Communicating to that audience is a distinct discipline, and getting it wrong is expensive.' },
      { kind: 'h', text: 'What a risk-pricing audience needs' },
      { kind: 'list', text: '', items: [
        'A clear, quantified path, not a vibe of momentum.',
        'The risks named by you, because unnamed risks look like ones you missed.',
        'Consistency between what you tell the press and what you tell the room.',
        'Evidence, because in this audience assertions without proof lower your price.'] },
      { kind: 'quote', text: 'Naming your risks does not make you look weaker. It makes you look like someone who can be trusted with the upside.' },
      { kind: 'h', text: 'Aligning the narrative' },
      { kind: 'p', text: 'The public story and the investor story must be the same story, told at different depths. When the coverage, the deck and the conversation all reinforce one credible narrative, confidence rises and so, usually, does the valuation.' },
      { kind: 'p', text: 'Growth communications is not about sounding more excited. It is about being believed by the people who price your future.' },
    ],
  },
};
if (typeof module !== 'undefined') { module.exports = { ARTICLES }; }
